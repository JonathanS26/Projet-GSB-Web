<!--Formulaire de suppression à partir de l'identifiant -->
<br>
<br>
<br>
<br>
<div class="container">

<form action="" method=post>
<fieldset>
<legend>Entrez l'Id du materiel à supprimer </legend>
<label>Id :</label> <input type="text" name="ref" size="10" />
</fieldset>
<button type="submit" class="btn btn-primary">Supprimer</button>
<button type="reset" class="btn">Annuler</button>
</form>

</div>