
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<!--Vue pour la saisie des informations dans un formulaire!-->

<div class="container">

<form name="formAjout" action="" method="post">
  <fieldset>
    <legend>Entrez les donnees sur l'empreint à ajouter </legend>
    <label> date Empunter : </label> <input type="text" name="dateEmprunter" /><br />
    <label> date Restituer : </label> <input type="text" name="dateRestituer" /><br />
    <label>vis_matricule:</label> <input type="text" name="vis_matricule" /><br />
    <label>idMateriel:</label> <input type="text" name="idMateriel" /><br />
       
   
  </fieldset>
  <button type="submit" class="btn btn-primary">Enregistrer</button>
  <button type="reset" class="btn">Annuler</button>
  </p>
</form>
</div>