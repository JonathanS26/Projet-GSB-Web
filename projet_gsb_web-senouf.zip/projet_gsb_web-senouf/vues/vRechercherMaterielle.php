
<--Saisie des informations dans un formulaire!-->
<br>
<br>
<br>
<br>
<br>
<div class="container">

<form name="formAjout" action="" method="post" onSubmit="return valider()">
  <fieldset>
    <legend>Entrez la designation de le materiel  recherchee </legend>
   <label>Modele :</label> <input type="text" name="des" size="20" /><br />
  </fieldset>
  <button type="submit" class="btn btn-primary">Rechercher</button>
  </p>
</form>
</div>


