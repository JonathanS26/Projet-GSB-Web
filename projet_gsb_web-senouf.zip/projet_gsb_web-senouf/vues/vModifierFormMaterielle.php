
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<!--Saisir les informations dans un formulaire!-->
<div class="container">
  <form action="" method=post>
    <input type="hidden" name="etape" value="3" />
<br>
<br>
<br>
<br>
<br>
    <fieldset>
      <legend>Entrez les donn�es sur le materiel � modifier </legend>
      <label> Id :</label>
      <input type="text" name="ref"  /><br />
      <label> Marque :</label>
      <input type="text" name="marque"  /><br />
      <label> Dimension :</label>
      <input type="text" name="dimension"  /><br />
      <label>Modele :</label>
      <input type="text" name="modele"  size="20" /><br />
    </fieldset>
    <button type="submit" class="btn btn-primary">Modifier</button>
    <button type="reset" class="btn">Annuler</button>
    </p>
  </form> 
</div>


