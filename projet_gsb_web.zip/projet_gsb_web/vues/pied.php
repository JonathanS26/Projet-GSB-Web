
    <!-- Pied de page
    ================================================== -->
    <div class="footer">
      <div class="container">
 
      <p > Appelez notre service commercial au 03.22.84.65.74 pour recevoir un bon de commande</p>
       
      </div>
    </div>

  </body>
</html>
