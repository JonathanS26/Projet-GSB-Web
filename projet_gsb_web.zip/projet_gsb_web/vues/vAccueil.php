  
   <!-- Vue d'accueil
    ================================================== -->
 
<div class="jumbotron masthead">
  <div class="container">
    <h1>GSB Materiel</h1>
    <hr>
  </div>
</div>
