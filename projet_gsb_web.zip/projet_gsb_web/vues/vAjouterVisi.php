<br>
<br>
<br>
<br>
<br>
<br>



<!--Saisie des informations dans un formulaire!-->
<div class="container">

<form name="ajoutVisi" action="" method="post" onSubmit="return valider()">
  <fieldset>
    <legend>Entrez les données le visiteur a ajouter </legend>
    <label> ID : </label> <input type="text" placeholder="Entrer l'ID" name="id" size="10" /><br />
    <label>Nom :</label> <input type="text" name="nom" size="20" /><br />
    <label>Mot de Pass :</label> <input type="text" name="mdp" size="10" /><br />
    <label>Rôle :</label> <input type="text" name="role" size="20"/><br />    
  </fieldset>
  <button type="submit" class="btn btn-primary">Enregistrer</button>
  <button type="reset" class="btn">Annuler</button>
  <p />
</form>
</div>


