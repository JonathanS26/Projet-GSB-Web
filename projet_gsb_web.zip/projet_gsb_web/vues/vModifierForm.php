<!--Saisir les informations dans un formulaire!-->
<div class="container">
  <form action="" method=post>
    <input type="hidden" name="etape" value="3" />

    <fieldset>
      <legend>Entrez les donn�es sur le visiteur � modifier </legend>
      <label> Matricule :</label>
      <input type="text" name="ref"  /><br />
      <label> Nom :</label>
      <input type="text" name="nom"  /><br />
      <label> Prenom :</label>
      <input type="text" name="prenom"  /><br />
      <label>Adresse :</label>
      <input type="text" name="adresse"  size="20" /><br />
      <label>CP :</label>
      <input type="text" name="cp"  /><br />
      <label>Ville :</label>
      <input type="text" name="ville" /><br />
      <label>Sec_code :</label>
      <input type="text" name="sec_code" /><br />
      <label>Lab_code :</label>
      <input type="text" name="lab_code" /><br />
    </fieldset>
    <button type="submit" class="btn btn-primary">Modifier</button>
    <button type="reset" class="btn">Annuler</button>
    </p>
  </form> 
</div>


